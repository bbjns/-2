function calculate() {
  const rate = parseFloat(document.getElementById('fundingRate').value) / 100;
  const lev = parseFloat(document.getElementById('leverage').value);
  const fee = parseFloat(document.getElementById('fee').value) / 100;
  const slip = parseFloat(document.getElementById('slippage').value) / 100;
  const interest = parseFloat(document.getElementById('interest').value) / 100;
  const cap = parseFloat(document.getElementById('capital').value);
  const hours = parseFloat(document.getElementById('hours').value);

  const fundingProfit = cap * lev * rate * hours;
  const totalFee = cap * lev * (fee + slip);
  const borrowCost = cap * lev * (interest / 8760 * hours);
  const netProfit = fundingProfit - totalFee - borrowCost;
  const netRate = netProfit / cap * 100;
  const dailyReturn = (netRate / (hours / 24)).toFixed(4);
  const annualReturn = (dailyReturn * 365 / 100).toFixed(2);

  document.getElementById('arbitrageResult').innerText =
    netProfit > 0 ? '✅ 当前费率可套利' : '❌ 当前费率不可套利';
  document.getElementById('netProfit').innerText =
    '净收益率: ' + netRate.toFixed(4) + '% (' + netProfit.toFixed(2) + ' USDT)';
  document.getElementById('dailyReturn').innerText =
    '日化收益率: ' + dailyReturn + '%';
  document.getElementById('annualReturn').innerText =
    '年化收益率: ' + annualReturn + '%';
}

function setLanguage(lang) {
  document.documentElement.lang = lang;
}
